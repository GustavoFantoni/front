var area = document.querySelector("section.slider-images");
var img1

const arrayImages = ["images/image 5" , "images/image 5", "images/image 5"];

